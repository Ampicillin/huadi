import pandas as pd
import numpy as np
import time
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.pipeline import Pipeline
import joblib

# 设置中文显示
plt.rcParams["font.family"] = ["SimHei"]
plt.rcParams["axes.unicode_minus"] = False


# 1. 数据加载与预处理
def load_and_preprocess_data(file_path):
    # 加载数据
    df = pd.read_excel(file_path)

    # 查看缺失值
    print("缺失值情况：")
    print(df.isnull().sum())

    # 对分类变量进行编码
    categorical_cols = ['性别', '职业', '学历', '心电']
    label_encoders = {}
    for col in categorical_cols:
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col])
        label_encoders[col] = le

    # 构建更多特征
    df['血压比'] = df['收缩压'] / df['舒张压']
    df['BMI分类'] = pd.cut(df['BMI'], bins=[0, 18.5, 24, 28, 100], labels=[0, 1, 2, 3])
    df['血糖分类'] = pd.cut(df['血糖(mmol/L)'], bins=[0, 6.1, 7.0, 100], labels=[0, 1, 2])

    return df, label_encoders


# 2. 定义健康风险评估函数
def define_health_risk(df):
    def health_risk(row):
        """根据医学标准定义健康风险等级"""
        age = row['年龄']
        systolic = row['收缩压']
        diastolic = row['舒张压']
        glucose = row['血糖(mmol/L)']
        bmi = row['BMI']

        # 初始化风险分数
        risk_score = 0

        # 年龄因素
        if age > 75:
            risk_score += 3
        elif age > 65:
            risk_score += 2
        elif age > 55:
            risk_score += 1

        # 血压因素
        if systolic >= 140 or diastolic >= 90:  # 高血压
            risk_score += 3
        elif systolic >= 130 or diastolic >= 85:  # 正常高值
            risk_score += 2

        # 血糖因素
        if glucose >= 7.0:  # 糖尿病
            risk_score += 3
        elif glucose >= 6.1:  # 空腹血糖受损
            risk_score += 2

        # BMI因素
        if bmi >= 28:  # 肥胖
            risk_score += 2
        elif bmi >= 24:  # 超重
            risk_score += 1

        # 风险等级划分
        if risk_score >= 5:
            return '高'
        elif risk_score >= 3:
            return '中'
        else:
            return '低'

    # 生成目标列
    df['健康风险等级'] = df.apply(health_risk, axis=1)
    return df


# 3. 多模型对比
def compare_models(X, y):
    # 划分训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # 定义多种模型
    models = {
        "随机森林": Pipeline([
            ('scaler', StandardScaler()),
            ('classifier', RandomForestClassifier(random_state=42))
        ]),
        "梯度提升树": Pipeline([
            ('scaler', StandardScaler()),
            ('classifier', GradientBoostingClassifier(random_state=42))
        ]),
        "逻辑回归": Pipeline([
            ('scaler', StandardScaler()),
            ('classifier', LogisticRegression(max_iter=1000, random_state=42))
        ]),
        "支持向量机": Pipeline([
            ('scaler', StandardScaler()),
            ('classifier', SVC(random_state=42))
        ]),
        "K近邻": Pipeline([
            ('scaler', StandardScaler()),
            ('classifier', KNeighborsClassifier())
        ]),
        "高斯朴素贝叶斯": Pipeline([
            ('scaler', StandardScaler()),
            ('classifier', GaussianNB())
        ]),
        "决策树": Pipeline([
            ('scaler', StandardScaler()),
            ('classifier', DecisionTreeClassifier(random_state=42))
        ])
    }

    # 存储模型性能指标
    results = {
        "模型": [],
        "准确率": [],
        "F1分数": [],
        "训练时间(s)": [],
        "5折交叉验证F1": []
    }

    # 遍历模型进行训练和评估
    for name, model in models.items():
        print(f"=== 训练{name} ===")

        # 记录训练时间
        start_time = time.time()

        # 训练模型
        model.fit(X_train, y_train)

        # 计算训练时间
        train_time = round(time.time() - start_time, 2)

        # 预测测试集
        y_pred = model.predict(X_test)

        # 评估指标
        acc = round(accuracy_score(y_test, y_pred), 4)
        f1 = round(f1_score(y_test, y_pred, average="macro"), 4)

        # 交叉验证
        cv_f1 = round(cross_val_score(
            model, X_train, y_train, cv=5, scoring="f1_macro"
        ).mean(), 4)

        # 保存结果
        results["模型"].append(name)
        results["准确率"].append(acc)
        results["F1分数"].append(f1)
        results["训练时间(s)"].append(train_time)
        results["5折交叉验证F1"].append(cv_f1)

        # 输出分类报告
        print(f"{name}分类报告:\n", classification_report(y_test, y_pred))

        # 保存模型
        joblib.dump(model, f"{name.replace(' ', '_')}_model.pkl")

    # 转换为DataFrame
    results_df = pd.DataFrame(results)

    # 可视化对比结果
    plt.figure(figsize=(12, 8))

    # 准确率对比
    plt.subplot(2, 2, 1)
    sns.barplot(x="模型", y="准确率", data=results_df)
    plt.title("模型准确率对比")
    plt.ylim(0, 1.1)

    # F1分数对比
    plt.subplot(2, 2, 2)
    sns.barplot(x="模型", y="F1分数", data=results_df)
    plt.title("模型F1分数对比")
    plt.ylim(0, 1.1)

    # 训练时间对比
    plt.subplot(2, 2, 3)
    sns.barplot(x="模型", y="训练时间(s)", data=results_df)
    plt.title("模型训练时间对比")

    # 交叉验证F1对比
    plt.subplot(2, 2, 4)
    sns.barplot(x="模型", y="5折交叉验证F1", data=results_df)
    plt.title("模型交叉验证F1对比")
    plt.ylim(0, 1.1)

    plt.tight_layout()
    plt.savefig("模型对比结果.png")
    plt.close()

    # 保存对比结果到CSV
    results_df.to_csv("模型对比结果.csv", index=False)

    return results_df


# 4. 对所有样本进行预测并保存结果
def predict_all_samples(df, model, selected_features, output_file):
    # 选择特征
    X_full = df[selected_features]

    # 对所有样本进行预测
    df['预测风险等级'] = model.predict(X_full)

    # 保存结果
    result_cols = ['姓名', '年龄', '性别', '收缩压', '舒张压', '血糖(mmol/L)', 'BMI', '预测风险等级']
    df[result_cols].to_excel(output_file, index=False)
    print(f"所有样本的风险评估结果已保存至：{output_file}")

    return df


# 主函数
def main():
    # 加载和预处理数据
    file_path = './项目数据_clean.xlsx'
    df, label_encoders = load_and_preprocess_data(file_path)

    # 定义健康风险等级
    df = define_health_risk(df)

    # 准备特征和目标变量
    selected_features = [
        '年龄', '性别', '收缩压', '舒张压', '血糖(mmol/L)', 'BMI', '腰臀比',
        '血压比', 'BMI分类', '血糖分类', '胆固醇', '尿酸', '骨密度', '心率', '呼吸'
    ]
    X = df[selected_features]
    y = df['健康风险等级']

    # 多模型对比
    results_df = compare_models(X, y)
    print("\n=== 模型性能对比结果 ===")
    print(results_df)

    # 选择最优模型（以F1分数为准）
    best_model_name = results_df.loc[results_df['F1分数'].idxmax(), '模型']
    best_model = joblib.load(f"{best_model_name.replace(' ', '_')}_model.pkl")
    print(f"\n最优模型: {best_model_name}")

    # 对所有样本进行预测并保存结果
    predict_all_samples(df, best_model, selected_features, "全量样本风险评估结果.xlsx")

    # 保存特征重要性（仅对树模型有效）
    if best_model_name in ["随机森林", "梯度提升树", "决策树"]:
        try:
            feature_importance = pd.DataFrame({
                '特征': selected_features,
                '重要性': best_model.named_steps['classifier'].feature_importances_
            }).sort_values('重要性', ascending=False)

            feature_importance.to_csv("特征重要性.csv", index=False)
            print("\n特征重要性已保存至：特征重要性.csv")
        except:
            print("\n无法获取特征重要性")


if __name__ == "__main__":
    main()