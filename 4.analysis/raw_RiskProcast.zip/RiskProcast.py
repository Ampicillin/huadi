import pandas as pd
import joblib
from sklearn.preprocessing import LabelEncoder

# 1. 加载数据和模型
# 加载原始数据（确保与训练时的特征处理逻辑一致）
df = pd.read_excel('./项目数据_clean.xlsx')

# 加载训练好的模型
final_model = joblib.load('health_risk_model.pkl')

# 2. 重复特征工程步骤（与训练时保持一致，避免特征不匹配）
# 对分类变量编码（使用训练时保存的LabelEncoder）
# （如果之前未保存label_encoders，需重新执行编码逻辑，或从训练代码中复用）
categorical_cols = ['性别', '职业', '学历', '心电']
label_encoders = {}
for col in categorical_cols:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    label_encoders[col] = le

# 构建特征（与训练时完全一致）
df['血压比'] = df['收缩压'] / df['舒张压']
df['BMI分类'] = pd.cut(df['BMI'], bins=[0, 18.5, 24, 28, 100], labels=[0, 1, 2, 3])
df['血糖分类'] = pd.cut(df['血糖(mmol/L)'], bins=[0, 6.1, 7.0, 100], labels=[0, 1, 2])

# 选择特征（与训练时的selected_features一致）
selected_features = [
    '年龄', '性别', '收缩压', '舒张压', '血糖(mmol/L)', 'BMI', '腰臀比',
    '血压比', 'BMI分类', '血糖分类', '胆固醇', '尿酸', '骨密度', '心率', '呼吸'
]
X_full = df[selected_features]

# 3. 对所有样本进行预测
df['预测风险等级'] = final_model.predict(X_full)

# 4. 保存结果（保留原始信息+预测结果）
# 选择需要保留的原始列（如姓名、年龄、原始指标等）+ 预测结果
result_cols = ['姓名', '年龄', '性别', '收缩压', '舒张压', '血糖(mmol/L)', 'BMI', '预测风险等级']
df[result_cols].to_excel('全量样本风险评估结果.xlsx', index=False)
print("所有样本的风险评估结果已保存至：全量样本风险评估结果.xlsx")