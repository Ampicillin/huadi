import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score
from sklearn.feature_selection import SelectKBest, f_classif
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler

# 设置中文显示
plt.rcParams["font.family"] = ["SimHei"]
plt.rcParams["axes.unicode_minus"] = False  # 解决负号显示问题

# 加载数据
df = pd.read_excel('./项目数据_clean.xlsx')

# 1. 数据探索与可视化
print('数据基本信息：')
df.info()

# 查看数据集行数和列数
rows, columns = df.shape

if rows < 100 and columns < 20:
    # 短表数据查看全量数据信息
    print('数据全部内容信息：')
    print(df.to_csv(sep='\t', na_rep='nan'))
else:
    # 长表数据查看数据前几行信息
    print('数据前几行内容信息：')
    print(df.head().to_csv(sep='\t', na_rep='nan'))

# 可视化特征分布
numeric_features = ['年龄', '收缩压', '舒张压', '血糖(mmol/L)', 'BMI', '腰臀比']
plt.figure(figsize=(15, 10))
for i, feature in enumerate(numeric_features, 1):
    plt.subplot(2, 3, i)
    sns.histplot(df[feature], kde=True)
    plt.title(f'{feature}分布')
plt.tight_layout()
plt.savefig('特征分布.png')
plt.close()

# 2. 特征工程
# 对分类变量进行编码
categorical_cols = ['性别', '职业', '学历', '心电']
label_encoders = {}
for col in categorical_cols:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    label_encoders[col] = le

# 构建更多特征
df['血压比'] = df['收缩压'] / df['舒张压']
df['BMI分类'] = pd.cut(df['BMI'], bins=[0, 18.5, 24, 28, 100], labels=[0, 1, 2, 3])  # 偏瘦,正常,过重,肥胖
df['血糖分类'] = pd.cut(df['血糖(mmol/L)'], bins=[0, 6.1, 7.0, 100], labels=[0, 1, 2])  # 正常,空腹血糖受损,糖尿病


# 3. 定义健康风险评估函数
def health_risk(row):
    """根据医学标准定义健康风险等级"""
    age = row['年龄']
    systolic = row['收缩压']
    diastolic = row['舒张压']
    glucose = row['血糖(mmol/L)']
    bmi = row['BMI']

    # 初始化风险分数
    risk_score = 0

    # 年龄因素
    if age > 75:
        risk_score += 3
    elif age > 65:
        risk_score += 2
    elif age > 55:
        risk_score += 1

    # 血压因素
    if systolic >= 140 or diastolic >= 90:  # 高血压
        risk_score += 3
    elif systolic >= 130 or diastolic >= 85:  # 正常高值
        risk_score += 2

    # 血糖因素
    if glucose >= 7.0:  # 糖尿病
        risk_score += 3
    elif glucose >= 6.1:  # 空腹血糖受损
        risk_score += 2

    # BMI因素
    if bmi >= 28:  # 肥胖
        risk_score += 2
    elif bmi >= 24:  # 超重
        risk_score += 1

    # 风险等级划分
    if risk_score >= 5:
        return '高'
    elif risk_score >= 3:
        return '中'
    else:
        return '低'


# 生成目标列
df['健康风险等级'] = df.apply(health_risk, axis=1)

# 4. 特征选择
# 准备特征和目标变量
selected_features = [
    '年龄', '性别', '收缩压', '舒张压', '血糖(mmol/L)', 'BMI', '腰臀比',
    '血压比', 'BMI分类', '血糖分类', '胆固醇', '尿酸', '骨密度', '心率', '呼吸'
]
X = df[selected_features]
y = df['健康风险等级']

# 特征重要性分析
selector = SelectKBest(score_func=f_classif, k=10)
X_selected = selector.fit_transform(X, y)

# 获取特征得分
feature_scores = pd.DataFrame({
    '特征': selected_features,
    '得分': selector.scores_
}).sort_values('得分', ascending=False)

print('特征重要性得分:')
print(feature_scores)

# 5. 模型训练与评估
# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# 定义预处理管道
preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), selected_features)
    ])


# 定义模型评估函数
def evaluate_model(model, X_train, X_test, y_train, y_test):
    # 交叉验证
    cv_scores = cross_val_score(model, X_train, y_train, cv=5, scoring='f1_macro')
    print(f'交叉验证 F1 分数: {np.mean(cv_scores):.4f} ± {np.std(cv_scores):.4f}')

    # 训练模型
    model.fit(X_train, y_train)

    # 在测试集上的表现
    y_pred = model.predict(X_test)

    print('\n测试集评估结果:')
    print(f'准确率: {accuracy_score(y_test, y_pred):.4f}')
    print(f'F1 分数: {f1_score(y_test, y_pred, average="macro"):.4f}')

    # 分类报告
    print('\n分类报告:')
    print(classification_report(y_test, y_pred))

    # 混淆矩阵
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=['低', '中', '高'], yticklabels=['低', '中', '高'])
    plt.xlabel('预测风险等级')
    plt.ylabel('实际风险等级')
    plt.title('混淆矩阵')
    plt.savefig('混淆矩阵.png')
    plt.close()

    return model


# 6. 模型比较与选择
# 随机森林模型
rf_pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', RandomForestClassifier(random_state=42))
])

# 梯度提升树模型
gb_pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', GradientBoostingClassifier(random_state=42))
])

# 评估随机森林模型
print('\n==== 随机森林模型 ====')
rf_model = evaluate_model(rf_pipeline, X_train, X_test, y_train, y_test)

# 评估梯度提升树模型
print('\n==== 梯度提升树模型 ====')
gb_model = evaluate_model(gb_pipeline, X_train, X_test, y_train, y_test)

# 7. 模型调优
# 选择表现更好的模型进行参数调优
if f1_score(y_test, rf_model.predict(X_test), average="macro") > f1_score(y_test, gb_model.predict(X_test),
                                                                          average="macro"):
    best_model = rf_model
    param_grid = {
        'classifier__n_estimators': [100, 200, 300],
        'classifier__max_depth': [None, 10, 20, 30],
        'classifier__min_samples_split': [2, 5, 10]
    }
else:
    best_model = gb_model
    param_grid = {
        'classifier__n_estimators': [100, 200, 300],
        'classifier__learning_rate': [0.01, 0.1, 0.2],
        'classifier__max_depth': [3, 5, 7]
    }

# 网格搜索调参
grid_search = GridSearchCV(
    best_model, param_grid, cv=5, scoring='f1_macro', n_jobs=-1, verbose=2
)

print('\n==== 开始网格搜索调参 ====')
grid_search.fit(X_train, y_train)

print('最佳参数:')
print(grid_search.best_params_)

print('\n==== 最终模型评估 ====')
final_model = grid_search.best_estimator_
final_model.fit(X_train, y_train)
y_pred = final_model.predict(X_test)

print(f'最终模型准确率: {accuracy_score(y_test, y_pred):.4f}')
print(f'最终模型 F1 分数: {f1_score(y_test, y_pred, average="macro"):.4f}')

# 8. 保存模型
import joblib

joblib.dump(final_model, 'health_risk_model.pkl')
print('模型已保存为: health_risk_model.pkl')

# 9. 预测示例
sample = X_test.iloc[0:5].copy()
sample_predictions = final_model.predict(sample)
print('\n预测示例:')
for i in range(len(sample)):
    print(f"样本 {i + 1}: 预测风险等级 = {sample_predictions[i]}")